﻿using LinkvertiseBypass.Linkvertise;

Linkvertise linkvertise = new Linkvertise();
await linkvertise.Bypass(new Uri("link_here"));